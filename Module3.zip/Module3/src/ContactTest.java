import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class contactTest {

	@Test
	void testContactClass() {
		Contact newContact = new Contact("test", "first", "last", "1234567890", "address");
		assertTrue(newContact.getContactID().equals("test"));
		assertTrue(newContact.getFirstName().equals("first"));
		assertTrue(newContact.getLastName().equals("last"));
		assertTrue(newContact.getPhoneNumber().equals("1234567890"));
		assertTrue(newContact.getAddress().equals("address"));
	}
	
	
	@Test
	void testContactIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("test5678901", "first", "last", "1234567890", "address");
		});
	}
	@Test
	void testContactIDNULL() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "first", "last", "1234567890", "address");
			
		});
		
	}
	
	@Test
	void testFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("test", "first123456789", "last", "1234567890", "address");
		});
	}
	@Test
	void testFirstNameNULL() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("test", null, "last", "1234567890", "address");
			
		});
		
	}
	@Test
	void testLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("test", "first", "last123456789", "1234567890", "address");
		});
	}
	@Test
	void testLastNameNULL() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("test", "first", null, "1234567890", "address");
			
		});
		
	}
	@Test
	void testPhoneNumberLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("test", "first", "last", "123456789", "address");
		});
	}
	@Test
	void testPhoneNumberNULL() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("test", "first", "last", null, "address");
			
		});
		
	}
	@Test
	void testAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("test", "first", "last", "1234567890", "address11111111111111111111111111111111111111");
		});
	}
	@Test
	void testAddressNULL() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("test", "first", "last", "1234567890", null);
			
		});
		
	}
	@Test
	void testSetFirstName() {
		Contact newContact = new Contact("test", "first", "last", "1234567890", "address");
		newContact.setFirstName("first1");
		assertTrue(newContact.getFirstName().equals("first1"));
	}
	@Test
	void testSetFirstNameTooLong() {
		Contact newContact = new Contact("test", "first", "last", "1234567890", "address");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setFirstName("first123456789123456");
			
		});
			
	}
	@Test
	void testSetFirstNameNull() {
		Contact newContact = new Contact("test", "first", "last", "1234567890", "address");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setFirstName(null);
			
		});
			
	}
	@Test
	void testSetLastName() {
		Contact newContact = new Contact("test", "first", "last", "1234567890", "address");
		newContact.setLastName("first1");
		assertTrue(newContact.getLastName().equals("first1"));
	}
	@Test
	void testSetLastNameTooLong() {
		Contact newContact = new Contact("test", "first", "last", "1234567890", "address");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setLastName("first123456789123456");
			
		});
			
	}
	@Test
	void testSetLastNameNull() {
		Contact newContact = new Contact("test", "first", "last", "1234567890", "address");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setLastName(null);
			
		});
			
	}
	@Test
	void testSetPhoneNumber() {
		Contact newContact = new Contact("test", "first", "last", "1234567890", "address");
		newContact.setPhoneNumber("0987654321");
		assertTrue(newContact.getPhoneNumber().equals("0987654321"));
	}
	@Test
	void testSetPhoneNumberNotTen() {
		Contact newContact = new Contact("test", "first", "last", "1234567890", "address");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setPhoneNumber("1234");
			
		});
			
	}
	@Test
	void testSetPhoneNumberNull() {
		Contact newContact = new Contact("test", "first", "last", "1234567890", "address");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setPhoneNumber(null);
			
		});
			
	}
	@Test
	void testSetAddress() {
		Contact newContact = new Contact("test", "first", "last", "1234567890", "address");
		newContact.setAddress("first1");
		assertTrue(newContact.getAddress().equals("first1"));
	}
	@Test
	void testSetAddressTooLong() {
		Contact newContact = new Contact("test", "first", "last", "1234567890", "address");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setFirstName("first123456789123456789111111111111111111111111111");
			
		});
			
	}
	@Test
	void testSetAddressNull() {
		Contact newContact = new Contact("test", "first", "last", "1234567890", "address");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setAddress(null);
			
		});
			
	}
}
	
	
	

